package com.springboot.springbootlogindemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootLoginDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootLoginDemoApplication.class, args);
    }

}
