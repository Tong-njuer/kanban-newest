package com.springboot.springbootlogindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLoginDemoApplicationTests {

    @Test
    void contextLoads() {
    }
}
