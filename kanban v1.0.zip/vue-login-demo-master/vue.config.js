module.exports = {
  lintOnSave: false,
  // 开启代理服务器
  devServer: {
    proxy: {
      "/api": {
        target: "http://localhost:8082",
        ws: true,
        changeOrigin: true,
        pathRewrite: {
          "^/api": "",
        },
      },
    },
  },
};
