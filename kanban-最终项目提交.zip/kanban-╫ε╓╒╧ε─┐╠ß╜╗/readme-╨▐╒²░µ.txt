学号：231250008

姓名：徐立桐

git仓库地址：https://github.com/Tong-njuer/kanban-newest.git

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

本项目由三部分整合而成：

1、基于react框架的敏捷看板项目；

2、基于Vue框架的用户登陆注册前端项目；

3、Spring Boot用户数据后端项目，利用mysql生成管理数据库；

react看板项目和vue登陆注册项目分别构建生成静态文件，放在Spring Boot Login项目的\src\main\resources目录下；

然后用Maven构建Spring Boot项目，生成可执行的JAR文件。

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

具体功能实现与运行：

1、使用Java8(<java.version>1.8</java.version>)(windows11)进行开发，Spring Boot用的是2.3.12.RELEASE 版本，理论上Java8~14都可用；

运行前注意注意！请安装MySQL，并且在自己的计算机上设置 MySQL 数据库来配置Spring Boot 应用程序！否则项目无法运行！

1)安装MySQL，网上非常多教程，如果已有请忽略安装步骤。有server即可

2)启动 MySQL 客户端：

打开终端或命令提示符，输入以下命令以进入 MySQL 客户端，并输入你所设置的密码来登录：

mysql -u root -p

在 MySQL 客户端中运行以下命令来创建数据库（请勿更改名字）：

CREATE DATABASE logindemo;

进入数据库：

use logindemo；

然后创建一个user表来存储用户账号信息：

   ```sql```
   CREATE TABLE user
   (
       uid int(10) primary key NOT NULL AUTO_INCREMENT,
       uname varchar(30) NOT NULL,
       password varchar(255) NOT NULL,
       UNIQUE (uname)
   );
   `````````

检查是否创建成功：（非必须）

desc user;

这样就完成了系统数据库的配置；

创建一个新用户并授权其访问数据库(项目开发时创建的用户是myuser，密码是mypassword)：

CREATE USER 'myuser'@'localhost' IDENTIFIED BY 'mypassword';

GRANT ALL PRIVILEGES ON logindemo.* TO 'myuser'@'localhost';

FLUSH PRIVILEGES;

这样就完成了数据库的配置，可以储存用户名和密码等信息，实现和后端项目的对接。

2、在kanban.jar所在目录下打开命令行，用命令

java -jar kanban.jar

运行jar文件，启动 Spring Boot 应用，并输出相关的启动日志信息，项目会在本地8082端口运行，打开浏览器输入地址

http://localhost:8082/

打开项目登录界面，点击注册并填入用户名 密码，回到登录界面登录，后端校验用户信息成功即可跳转到看板界面（其实也可以直接访问http://localhost:8082/build/index.html打开看板界面但那我登陆注册的前后端项目不是白做了吗

3、使用看板：

~进入看板界面，初始默认空白看板，点击左列创建新空白看板，点击看板名称实现看板项目切换，点击上方“删除当前看板”可删除当前项目看板

~三列项目泳道，点击+号实现创建新任务，输入任务名称和任务评论

~点击任务方块展开详情，查看任务评论并编辑任务评论内容

~点击选择文件为任务上传附件，并可点击预览附件

~任务名、任务评论、附件均可编辑，点击删除任务按钮删除当前任务

~按住左键拖动任务方块在不同任务列之间任意移动

~~~~~~以上，实现评分细则中的所有8项基本功能，并且有额外完成的功能，例如附件预览、评论更新、任务方块拖拽、用户注册、后端数据库的应用等等。